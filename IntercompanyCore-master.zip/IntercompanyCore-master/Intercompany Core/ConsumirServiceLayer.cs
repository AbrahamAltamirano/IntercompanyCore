﻿using B1SLayer;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntercompanyCore
{
    public class ConsumirServiceLayer
    {

        public async Task<string> CreateBusinessPartnerAsync(SLConnection serviceLayer, SocioNegocios socio)
        {
            string response = "";
            BusinessPartner bp = new BusinessPartner();
            bp.CardCode = socio.CodSocioNegocios;
            bp.CardName = socio.Nombre;
            bp.GroupCode = socio.Grupo;
            bp.CardType = socio.TipoSN;
            bp.FederalTaxID = socio.RFC;
            bp.Currency = socio.Moneda;
            await serviceLayer.Request("BusinessPartners").PostAsync<BusinessPartner>(bp);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;
            });
            return response;
        }
        public async Task<string> PatchBusinessPartnerAsync(SLConnection serviceLayer, SocioNegocios socio)
        {
            string response = "";
            BusinessPartner bp = new BusinessPartner();
            bp.CardCode = socio.CodSocioNegocios;
            bp.CardName = socio.Nombre;
            bp.GroupCode = socio.Grupo;
            bp.CardType = socio.TipoSN;
            bp.FederalTaxID = socio.RFC;
            bp.Currency = socio.Moneda;
            await serviceLayer.Request("BusinessPartners").PostAsync<BusinessPartner>(bp);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;
            });
            return response;
        }
        public async Task<string> CreateItemsAsync(SLConnection serviceLayer, Items item)
        {
            string response = "";
            Items_SL it = new Items_SL();
            it.ItemCode = item.CodItems;
            it.ItemName = item.Nombre;
            it.ItemType = "I";
            it.ItemsGroupCode = item.Grupo;
            it.InventoryItem = item.EsInventario;
            it.SalesItem = item.EsVentas;
            it.PurchaseItem = item.EsCompras;
            // Cambiar el resultado de GLMethod por su traduccion en ingles W: Warehouse = A, C: Item Group = G, L: Item Level=N  
            it.GLMethod = 'W';
            //it.EvalSystem = item.MetodoCosto;
            it.AvgStdPrice = item.Costo;
            it.Valid = item.EsValido;
            await serviceLayer.Request("Items").PostAsync<Items_SL>(it);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;

            });
            return response;
        }
        public async Task<string> PatchItemsAsync(SLConnection serviceLayer, Items item)
        {
            string response = "";
            Items_SL it = new Items_SL();
            it.ItemCode = item.CodItems;
            it.ItemName = item.Nombre;
            it.ItemType = "I";
            it.ItemsGroupCode = item.Grupo;
            it.InventoryItem = item.EsInventario;
            it.SalesItem = item.EsVentas;
            it.PurchaseItem = item.EsCompras;
            // Cambiar el resultado de GLMethod por su traduccion en ingles W: Warehouse = A, C: Item Group = G, L: Item Level=N  
            it.GLMethod = 'W';
            //it.EvalSystem = item.MetodoCosto;
            it.AvgStdPrice = item.Costo;
            it.Valid = item.EsValido;
            await serviceLayer.Request("Items").PostAsync<Items_SL>(it);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;

            });
            return response;
        }
        public async Task<string> CreateAccountsAsync(SLConnection serviceLayer, Cuentas cuenta)
        {
            string response = "";
            SocioNegocios socio = new SocioNegocios();
            var loginConexion = await serviceLayer.Request("BusinessPartners").PostAsync<SocioNegocios>(socio);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;

            });
            return response;
        }
        public async Task<string> PatchAccountsAsync(SLConnection serviceLayer, Cuentas cuenta)
        {
            string response = "";
            SocioNegocios socio = new SocioNegocios();
            var loginConexion = await serviceLayer.Request("BusinessPartners").PostAsync<SocioNegocios>(socio);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;

            });
            return response;
        }
        public async Task<string> CreateCostCenterAsync(SLConnection serviceLayer, CentrosCosto centro)
        {
            string response = "";
            SocioNegocios socio = new SocioNegocios();
            var loginConexion = await serviceLayer.Request("BusinessPartners").PostAsync<SocioNegocios>(socio);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;

            });
            return response;
        }
        public async Task<string> PatchCostCenterAsync(SLConnection serviceLayer, CentrosCosto centro)
        {
            string response = "";
            SocioNegocios socio = new SocioNegocios();
            var loginConexion = await serviceLayer.Request("BusinessPartners").PostAsync<SocioNegocios>(socio);
            serviceLayer.AfterCall(async call =>
            {
                response = call.RequestBody;

            });
            return response;
        }

    }
}
