﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntercompanyCore
{
    public class CostCenterTypes
    {
        public string CostCenterTypeCode { get; set; }
        public string CostCenterTypeName { get; set; }
    }
}

