﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntercompanyCore
{
    public class Items_SL
    {
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string ItemType { get; set; }
        public int ItemsGroupCode { get; set; }
        public char SalesItem { get; set; }
        public char InventoryItem { get; set; }
        public char PurchaseItem { get; set; }
        public char GLMethod { get; set; }
        //public char EvalSystem { get; set; }
        public double AvgStdPrice { get; set; }
        public char Valid { get; set; }
        //public DateOnly validTo { get; set; }
    }
}
