﻿using B1SLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntercompanyCore
{
    public class GenerarConexion
    {
        private LoginObj login = new LoginObj("TESTING_FUSION", "manager", "manager");
        public async Task<SLConnection> ConexionSLayerAsync()
        {
            SLConnection serviceLayer = new SLConnection("https://110.238.83.194:50000/b1s/v2", "TESTING_FUSION", "manager", "manager");

            serviceLayer.AfterCall(async call =>
            {
                Console.WriteLine($"Response: { call.HttpResponseMessage?.StatusCode}");
                Console.WriteLine(await call.HttpResponseMessage?.Content?.ReadAsStringAsync());

            });
            await serviceLayer.Request("Login").PostAsync<LoginObj>(login);
            return serviceLayer;
        }
    }
}

