﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntercompanyCore
{
    public class BusinessPartner
    {
        public string CardCode { get; set; }
        public int GroupCode { get; set; }
        public string CardName { get; set; }
        public string CardType { get; set; }
        public string FederalTaxID { get; set; }
        public string CmpPrivate { get; set; }
        public string Currency { get; set; }

        public BusinessPartner()
        {
        }

        public BusinessPartner(string cardCode, int groupCode, string cardName, string cardType, string federalTaxID, string companyPrivate, string currency)
        {
            CardCode = cardCode;
            GroupCode = groupCode;
            CardName = cardName;
            CardType = cardType;
            FederalTaxID = federalTaxID;
            CmpPrivate = companyPrivate;
            Currency = currency;
        }
    }

}
