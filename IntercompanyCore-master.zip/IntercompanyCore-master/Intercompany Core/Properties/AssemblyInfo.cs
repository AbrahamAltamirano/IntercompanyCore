using System.Runtime.InteropServices;

// En proyectos de estilo SDK como este, varios atributos de ensamblado que definían
// en este archivo se agregan ahora automáticamente durante la compilación y se rellenan
// con valores definidos en las propiedades del proyecto. Para obtener detalles acerca
// de los atributos que se incluyen y cómo personalizar este proceso, consulte https://aka.ms/assembly-info-properties


// Al establecer ComVisible en false, se consigue que los tipos de este ensamblado
// no sean visibles para los componentes COM. Si tiene que acceder a un tipo en este
// ensamblado desde COM, establezca el atributo ComVisible en true en ese tipo.

[assembly: ComVisible(false)]

// El siguiente GUID es para el identificador de typelib, si este proyecto se expone
// en COM.

[assembly: Guid("e88429e9-2652-4311-b1cb-1364f46d7512")]
