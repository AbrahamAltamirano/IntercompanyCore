﻿using IntercompanyCore;
using Microsoft.AspNetCore.Builder;
using B1SLayer;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using log4net;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Hosting;
using IntercompanyAPI.Controllers;
using AutoMapper;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore;
using System.Net.Http;
using System.Collections.Generic;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using IntercompanyCore.Entities;

namespace IntercompanyCore
{
	static class Program
	{

		private static readonly ILog log = Logs.GetLogger();
		private static readonly HttpClient client = new HttpClient();

		[STAThread]
		static async Task Main(string[] args)
		{
			try
			{
				// Generar conexion 
				GenerarConexion gc = new GenerarConexion();
				SLConnection serviceLayer = await gc.ConexionSLayerAsync();
				// Traer datos desincronizados de Transaccion 
				var streamTask = client.GetStreamAsync("https://localhost:7285/api/Transaccion/ObtenerTransacciones");
				var Transacciones = await System.Text.Json.JsonSerializer.DeserializeAsync<List<Transaccion>>(await streamTask);
				var transacciones = Transacciones.FindAll(t => t.Sincronizado == 'N');
				Console.WriteLine(transacciones.Count);
				// Traer SN, CU, CC e IT de la base de datos concentradora
				var CuentasTask = client.GetStreamAsync("https://localhost:7285/api/Cuentas/ObtenerTransaccionesCU");
				var Cuentas = await System.Text.Json.JsonSerializer.DeserializeAsync<List<Cuentas>>(await CuentasTask);

				var SociosTask = client.GetStreamAsync("https://localhost:7285/api/SocioNegocios/ObtenerTransaccionesSN");
				var Socios = await System.Text.Json.JsonSerializer.DeserializeAsync<List<SocioNegocios>>(await SociosTask);

				var ItemsTask = client.GetStreamAsync("https://localhost:7285/api/Items/ObtenerTransaccionesIT");
				var Items = await System.Text.Json.JsonSerializer.DeserializeAsync<List<Items>>(await ItemsTask);

				var CentrosTask = client.GetStreamAsync("https://localhost:7285/api/CentrosCosto/ObtenerTransaccionesCC");
				var Centros = await System.Text.Json.JsonSerializer.DeserializeAsync<List<CentrosCosto>>(await CentrosTask);

				// Crear contexto para usar SL 
				ConsumirServiceLayer csl = new ConsumirServiceLayer();
				for (int i = 0; i < transacciones.Count; i++)
				{
					switch (transacciones[i].TipodCRUD)
					{
						case "SN":
							SocioNegocios socio = Socios.Find(s => s.Clave == transacciones[i].IdObjeto);
							if (transacciones[i].TipoOperacion == 'A')
							{
								string body1 = await csl.CreateBusinessPartnerAsync(serviceLayer, socio);
								Transaccion transaccion = transacciones[i];
								transaccion.Sincronizado = 'Y';
								transaccion.FechaSincronizacion = DateTime.Now;
								transaccion.IdOrigen = transaccion.IdDestino;
								transaccion.JSON = body1;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, transaccion).Result;
							}
							else
							{
								string body2 = await csl.PatchBusinessPartnerAsync(serviceLayer, socio);
								Transaccion t2 = transacciones[i];
								t2.Sincronizado = 'Y';
								t2.FechaSincronizacion = DateTime.Now;
								t2.IdOrigen = t2.IdDestino;
								t2.JSON = body2;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, t2).Result;
							}
							break;
						case "CC":
							CentrosCosto centro = Centros.Find(c => c.Clave == transacciones[i].IdObjeto);
							if (transacciones[i].TipoOperacion == 'A')
							{
								string body3 = await csl.CreateCostCenterAsync(serviceLayer, centro);
								Transaccion t3 = transacciones[i];
								t3.Sincronizado = 'Y';
								t3.FechaSincronizacion = DateTime.Now;
								t3.IdOrigen = t3.IdDestino;
								t3.JSON = body3;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, t3).Result;
							}
							else
							{
								string body4 = await csl.PatchCostCenterAsync(serviceLayer, centro);
								Transaccion t4 = transacciones[i];
								t4.Sincronizado = 'Y';
								t4.FechaSincronizacion = DateTime.Now;
								t4.IdOrigen = t4.IdDestino;
								t4.JSON = body4;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, t4).Result;
							}
							break;
						case "CU":
							Cuentas cuenta = Cuentas.Find(s => s.Clave == transacciones[i].IdObjeto);
							if (transacciones[i].TipoOperacion == 'A')
							{
								string body5 = await csl.CreateAccountsAsync(serviceLayer, cuenta);
								Transaccion t5 = transacciones[i];
								t5.Sincronizado = 'Y';
								t5.FechaSincronizacion = DateTime.Now;
								t5.IdOrigen = t5.IdDestino;
								t5.JSON = body5;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, t5).Result;
							}
							else
							{
								string body6 = await csl.PatchAccountsAsync(serviceLayer, cuenta);
								Transaccion t6 = transacciones[i];
								t6.Sincronizado = 'Y';
								t6.FechaSincronizacion = DateTime.Now;
								t6.IdOrigen = t6.IdDestino;
								t6.JSON = body6;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, t6).Result;
							}
							break;
						case "IT":
							Items item = Items.Find(s => s.Clave == transacciones[i].IdObjeto);
							if (transacciones[i].TipoOperacion == 'A')
							{
								string body7 = await csl.CreateItemsAsync(serviceLayer, item);
								Transaccion t7 = transacciones[i];
								t7.Sincronizado = 'Y';
								t7.FechaSincronizacion = DateTime.Now;
								t7.IdOrigen = t7.IdDestino;
								t7.JSON = body7;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, t7).Result;
							}
							else
							{
								string body8 = await csl.PatchItemsAsync(serviceLayer, item);
								Transaccion t8 = transacciones[i];
								t8.Sincronizado = 'Y';
								t8.FechaSincronizacion = DateTime.Now;
								t8.IdOrigen = t8.IdDestino;
								t8.JSON = body8;
								client.BaseAddress = new Uri("https://localhost:7285/");
								var EditarTransaccion = client.PutAsJsonAsync("api/Transaccion/EditarTransaccion/" + transacciones[i].Id, t8).Result;
							}
							break;
					}
				}
			}
			catch (Exception ex)
			{
				log.Error(ex);
			}

		}

	}
}